//Getting all button Elements
const btns = document.querySelectorAll(
 '#btn');

//Getting The Reset Button Element
const resetBtn = document.getElementById('resetBtn');

//Getting Moves Elements
const playerPick = document.getElementById('playerPick');
const computerPick = document.getElementById('computerPick');

//Getting Result Element 
const resultId = document.getElementById('result');


// Getting Score Element 
const playerScoreId = document.getElementById('playerScore');
const computerScoreId = document.getElementById('computerScore');


// Getting moves Image Element
const playerMoveId = document.getElementById('playerMoveId');
const computerMoveId = document.getElementById('computerMoveId');

const playTimeId =   document.getElementById('timePlayed')

//Getting the moves Result Element
const moveResultId = document.getElementById('moveResult')

// Setting playing time to 0
let playTime = 0;
let timePlayed = 0;

btns.forEach((button) => {
 
 button.addEventListener('click',
  () => {
   
   // Selecting moves
   const playerMove = button.innerText;
   const computerMove = computer_Move();
   
   //Displaying Result
   const result = displayResult(playerMove, computerMove);
   resultId.innerHTML = result;
   
   if (result === 'You win!🎉') {
    resultId.style.color = '#39ff14'
   } else if (result === 'You lose!😡') {
    resultId.style.color = '#ff073a'
   } else {
    resultId.style.color = '#ffff33'
   };
   
   // Displaying moves text
   playerPick.innerHTML = `Player picked <br /> <span id="playerPickEl">'${playerMove}'</span>`;
   computerPick.innerHTML = `Computer picked <br /> <span id="computerPickEl">'${computerMove}'</span>`;
   
   
   // Displaying moves images
   playerMoveId.innerHTML = `
   <img src="player${playerMove}.png" alt="${playerMove} image" />
   `;
   computerMoveId.innerHTML = `
   <img src="computer${computerMove}.png" alt="${computerMove} image" />
   `;
   
   // Displaying moves result 
   const movesResult = moveResult(playerMove, computerMove);
   moveResultId.innerHTML = movesResult;
   document.getElementById('message').innerHTML = 'Result';
   
   // Updating result
   scoreUpdate(result);
   playerScoreId.innerHTML = playerScore;
   computerScoreId.innerHTML = computerScore;
   
   const final_Result = finalResult(playerScore, computerScore);
   
   // updating play time
   playTime++;
   
   if (playTime === 10) {
    btns.forEach((btn) => {
     btn.disabled = true;
    })
    setTimeout(() => {
     alert(final_Result);
    }, 1000)
   };
   return;
  })
 
});

// result function 
function displayResult(player, computer) {
 if (player === computer) {
  return 'A tie🤝';
 }
 else if (
  (player === 'Rock' && computer === 'Scissors') ||
  (player === 'Paper' && computer === 'Rock') ||
  (player === 'Scissors' && computer === 'Paper')
 ) {
  return 'You win!🎉';
 }
 else {
  return 'You lose!😡';
 }
};

// computer move function
function computer_Move() {
 const rand = Math.random();
 
 if (rand <= 1 / 3) {
  return 'Rock';
 }
 else if (rand <= 2 /
  3) {
  return 'Paper';
 }
 else {
  return 'Scissors';
 };
}


// score updating function

//default score
let playerScore = 0;
let computerScore = 0;

function scoreUpdate(score) {
 if (score === 'You win!🎉') {
  playerScore += 3;
  computerScore += 0;
 }
 else if (score === 'You lose!😡') {
  playerScore += 0;
  computerScore += 3;
 }
 else {
  playerScore++;
  computerScore++;
 }
 
};


// Final Pop up result 
function finalResult(player, computer) {
 if (player > computer) {
  return 'you won'
 } else if (player < computer) {
  return 'computer won'
 } else {
  return 'A tie'
 }
}


//move function 
function moveResult(player, computer) {
 
 if (
  (player === 'Rock' && computer === 'Scissors') ||
  (player === 'Scissors' && computer === 'Paper') ||
  (player === 'Paper' && computer === 'Rock')
 ) {
  return `${player} beats ${computer}`
 }
 else if (
  (computer === 'Rock' && player === 'Scissors') ||
  (computer === 'Scissors' && player === 'Paper') ||
  (computer === 'Paper' && player === 'Rock')
 ) {
  return `${computer} beats ${player}`
 }
 else {
  return 'This is a Tie'
 };
 
}

/*resetBtn.addEventListener('click', () => {
 playTime = 0;
 playerScore = 0;
 computerScore = 0;
 playerScoreId.innerHTML = 0;
 computerScoreId.innerHTML = 0;
})*/